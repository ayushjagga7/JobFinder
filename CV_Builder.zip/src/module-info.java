module cvBuilder {
    requires javafx.fxml;
    requires javafx.controls;
    requires java.sql;
    requires java.desktop;
//    requires rs2xml;

    opens sample;
}